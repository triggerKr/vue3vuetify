import { createApp } from "vue";
import App from "./App.vue";
//import Vuetify from 'vuetify';
import { createVuetify } from 'vuetify';
import 'vuetify/dist/vuetify.min.css';

import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
//import MDialog from "@/components/dialog";

const vuetify = createVuetify();
const app = createApp(App);

//MDialog._context = app._context;
//app.use(ElementPlus);
app.use(vuetify);
//app.use(MDialog);
app.mount("#app");

require('../node_modules/realgrid/dist/realgrid-style.css');