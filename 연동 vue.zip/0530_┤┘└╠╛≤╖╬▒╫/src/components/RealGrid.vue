<template>
  <!-- <el-dialog
    custom-class="TECHVUE-ELEMENT-PLUS-REALGRID"
    :title="title"
    v-model="dialogPopVisible"
    :width="width"
    :before-close="onBeforeClose"
    :center="true"
    v-bind="option"
  > -->
  
  <div id="realgrid" style="width: 600px; height: 300px"></div>

  <!-- </el-dialog> -->
</template>

<script>
//import { ElDialog } from "element-plus";
import { GridView, LocalDataProvider } from 'realgrid';
import { columns, fields, rows } from './realgrid-data';

let gridView = GridView;
let dataProvider = LocalDataProvider;

export default {
  data() {
    return {
      dialogPopVisible: true,
    };
  },
  components: { ElDialog },
  props: {
    title: {
      type: String,
      default: "TECHVUE-ELEMENT-PLUS-REALGRID",
    },
    width: {
      type: String,
      default: "1000px",
    },
    option: {
      type: Object,
      default: () => {},
    },
    remove: {
      type: Function,
    },
    comps: {
      require: false,
    },
  },
  methods: {
    onBeforeClose(done) {
      done();
    },
  },
  watch: {
    dialogPopVisible(value) {
      if (!value) {
        this.remove();
      }
    },
  },
  mounted() {
    setTimeout(function(){

    dataProvider = new LocalDataProvider(false);
    gridView = new GridView('realgrid');
    gridView.setDataSource(dataProvider);
    dataProvider.setFields(fields);
    gridView.setColumns(columns);
    dataProvider.setRows(rows);

    gridView.onCellDblClicked = function (grid, clickData) {
     console.log(clickData);
    }
    },1000)
  },
};
</script>

<style lang="scss">
.subDialog {
  &.el-dialog {
    z-index: 99;
    background-color: #ffffff;
    margin-top: 20% !important;
  }
  .el-dialog__header {
    width: 100%;
    height: 50px;
    line-height: 50px;
    box-sizing: border-box;
    padding: 0 25px;
    text-align: left;
    border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  }
  .el-dialog__headerbtn {
    font-size: 20px;
    width: 40px;
    height: 40px;
  }
  .el-dialog__title {
    font-size: 18px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: rgba(0, 0, 0, 0.85);
  }
  .el-dialog__body {
    box-sizing: border-box;
    padding: 20px 25px;
    height: 400px;
  }
  .el-dialog__footer {
    text-align: right;
    height: 60px;
    line-height: 60px;
    padding: 0;
    margin-right: 20px;
    border-top: 1px solid rgba(0, 0, 0, 0.06);
  }
}
</style>