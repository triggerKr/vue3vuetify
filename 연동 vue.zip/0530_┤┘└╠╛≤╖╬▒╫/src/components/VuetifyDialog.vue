<template>
  <v-app> <!-- v-app 컴포넌트 추가 -->
  <div class="text-center">
    <v-dialog
      v-model="dialog"
      width="auto"
    >
      <template v-slot:activator="{ props }">
        <v-btn
          color="primary"
          v-bind="props"
        >
          Open Dialog
        </v-btn>
      </template>

      <v-card>
        <v-card-text>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </v-card-text>
        <v-card-actions>
          <v-btn color="primary" block @click="dialog = false">Close Dialog</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</v-app>
</template>
 
 <script>
export default {
  data () {
    return {
      dialog: false,
    }
  },
}
</script> 

<style lang="scss">
/* Vuetify 스타일링 클래스 및 테마 적용 */
.v-application {
  background-color: #f5f5f5;
}

.theme--light.v-card {
  background-color: #ffffff;
  color: rgba(0, 0, 0, 0.87);
}

.theme--light.v-btn {
  font-weight: 500;
}

.theme--light.v-btn--active,
.theme--light.v-btn--active:hover {
  color: #ffffff;
  background-color: #1976d2;
}

.theme--light.v-btn--outlined {
  border: 2px solid #1976d2;
  color: #1976d2;
}

.theme--light.v-btn--outlined:hover {
  color: #ffffff;
  background-color: #1976d2;
}
.subDialog {
  &.el-dialog {
    z-index: 99;
    background-color: #ffffff;
    margin-top: 20% !important;
  }
  .el-dialog__header {
    width: 100%;
    height: 50px;
    line-height: 50px;
    box-sizing: border-box;
    padding: 0 25px;
    text-align: left;
    border-bottom: 1px solid rgba(0, 0, 0, 0.06);
  }
  .el-dialog__headerbtn {
    font-size: 20px;
    width: 40px;
    height: 40px;
  }
  .el-dialog__title {
    font-size: 18px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: rgba(0, 0, 0, 0.85);
  }
  .el-dialog__body {
    box-sizing: border-box;
    padding: 20px 25px;
    height: 400px;
  }
  .el-dialog__footer {
    text-align: right;
    height: 60px;
    line-height: 60px;
    padding: 0;
    margin-right: 20px;
    border-top: 1px solid rgba(0, 0, 0, 0.06);
  }
}
</style>