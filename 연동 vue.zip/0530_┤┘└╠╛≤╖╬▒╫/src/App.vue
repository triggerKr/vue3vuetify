<template>
  <h2>RealGrid Vue3 Sample TTTHECHYU</h2>
  <!-- <RealGrid />
  <Dialog /> -->
  <VuetifyDialog />
</template>

<script>
//import RealGrid from './components/RealGrid.vue';
//import Dialog from './components/Dialog.vue';
import VuetifyDialog from './components/VuetifyDialog.vue';

export default {
  name: 'App',
  components: {
  //  RealGrid,
  //  Dialog
  VuetifyDialog
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
  justify-content: center;
}
</style>
