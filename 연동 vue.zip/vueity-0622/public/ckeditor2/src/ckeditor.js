/**
 * @license Copyright (c) 2014-2023, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor.js';
import Alignment from '@ckeditor/ckeditor5-alignment/src/alignment.js';
import Base64UploadAdapter from '@ckeditor/ckeditor5-upload/src/adapters/base64uploadadapter.js';
import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials.js';
import GeneralHtmlSupport from '@ckeditor/ckeditor5-html-support/src/generalhtmlsupport.js';
import Image from '@ckeditor/ckeditor5-image/src/image.js';
import ImageToolbar from '@ckeditor/ckeditor5-image/src/imagetoolbar.js';
import ImageUpload from '@ckeditor/ckeditor5-image/src/imageupload.js';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph.js';
import Style from '@ckeditor/ckeditor5-style/src/style.js';
import Underline from '@ckeditor/ckeditor5-basic-styles/src/underline.js';

class Editor extends ClassicEditor {}

// Plugins to include in the build.
Editor.builtinPlugins = [
	Alignment,
	Base64UploadAdapter,
	Essentials,
	GeneralHtmlSupport,
	Image,
	ImageToolbar,
	ImageUpload,
	Paragraph,
	Style,
	Underline
];

// Editor configuration.
Editor.defaultConfig = {
	toolbar: {
		items: [
			'undo',
			'redo',
			'style',
			'underline',
			'alignment',
			'imageUpload'
		]
	},
	language: 'ko',
	image: {
		toolbar: [
			'imageTextAlternative'
		]
	}
};

export default Editor;
