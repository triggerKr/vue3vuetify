import { ValueType } from "realgrid";
//import { $t } from '../main' 
import _ from 'lodash';

export const fields = [
    {
      fieldName: "id",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "username",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "password",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "email",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "roles",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "createDate",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "createDateTime",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "loginDate",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "logoutDate",
      dataType: ValueType.TEXT,
    },
    {
      fieldName: "utcDate",
      dataType: ValueType.TEXT,
    },
];

fields.push(  {
  fieldName: "utcDate_1",
  dataType: ValueType.TEXT,
}, {
  fieldName: "utcDate_2",
  dataType: ValueType.TEXT,
})
// const i18Cols = {
//   id :  $t('title') ,
//   user: $t('user'),
//   password: $t('password')
// }

export const columns = [
    // {
    //     name: "id",
    //     fieldName: "id",
    //     width: "50",
    //     header: {
    //       text: "id",//i18Cols.id,
    //     },
    //   },  {
    //     name: "username",
    //     fieldName: "username",
    //     width: "100",
    //     header: {
    //       text: "user",//i18Cols.user,
    //     },
    //   },  {
    //     name: "password",
    //     fieldName: "password",
    //     width: "100",
    //     header: {
    //       text:  "password",//i18Cols.password,
    //     },
    //   },  {
    //     name: "email",
    //     fieldName: "email",
    //     width: "150",
    //     header: {
    //       text: "email",
    //     },
    //   },
    {
      name: "roles",
      fieldName: "roles",
      width: "80",
      header: {
        text: "roles",
      },
    },
    { 
      name: "createDate",
      fieldName: "createDate",
      width: "100",
      header: {
        text: "create Date",
      },
      editor:{
        "type": "date",
        "datetimeFormat": "yyyy-MM-dd",
        "textReadOnly": true,
        "mask": {
          "editMask": "9999-99-99",
          "includedFormat": true
          }       
      }
    },
    { 
      name: "createDateTime",
      fieldName: "createDateTime",
      width: "100",
      header: {
        text: "create Time",
      },
      renderer:{
        type:"html",
        callback: function(grid, cell, w, h) {
          return changeTime(cell);
        }
      },
    },
    // {
    //   name: "loginDate",
    //   fieldName: "loginDate",
    //   width: "100",
    //   header: {
    //     text: "loginDate",
    //   },
    // },
    // {
    //   name: "logoutDate",
    //   fieldName: "logoutDate",
    //   width: "100",
    //   header: {
    //     text: "logoutDate",
    //   },
    // },
    /**
     * date타입이 나오면, TEXT 컬럼을 두개 생성 하고 날짜컬럼,시간컬럼으로 나눈다. 
     */
    {
      name: "utcDate",
      fieldName: "utcDate",
      width: "200",
      header: {
        text: "utcDate",
      },
      renderer:{
        type:"html",
        callback: function(grid, cell, w, h) {
            let koreaTime = new Date(_.toNumber(cell.value) + (9 * 60 * 60 * 1000));
            let utcDate = formatUTCDate(koreaTime,"YYYY-MM-DD HH:MI:SS")
            return utcDate;
          },
      }
    },
    {
      name: "utcDate_1",
      fieldName: "utcDate_1",
      width: "200",
      header: {
        text: "UTC 날짜",
      },
      editor:{
        "type": "date",
        "datetimeFormat": "yyyy-MM-dd",
        "textReadOnly": true,
        "mask": {
          "editMask": "9999-99-99",
          "includedFormat": true
          }       
      },
      // renderer:{
      //   type:"html",
      //   callback: function(grid, cell, w, h) {
      //       let koreaTime = new Date(_.toNumber(cell.value) + (9 * 60 * 60 * 1000));
      //       let utcDate = formatUTCDate(koreaTime,"YYYY-MM-DD")
      //       return utcDate;
      //     },
      // }
    },
    {
      name: "utcDate_2",
      fieldName: "utcDate_2",
      width: "200",
      header: {
        text: "UTC 시간",
      },
     renderer:{
       type:"html",
       callback: function(grid, cell, w, h) {
        return changeTime(cell);
         },
      }
    },
];

const changeTime = (cell) => {
  
  console.log( "cell cell=========>  " +cell.value) ;
  var str ="";
  const tempVal = cell.value;
  let cellValLen = 3;
  let hour = "";
  let min = "";
  let sec = "";
  if( tempVal.indexOf(":") == -1 && tempVal.length == 6){
    hour= tempVal.substring(0,2);
    min = tempVal.substring(2,4);
    sec = tempVal.substring(4,6);
  }else{
    const cellVal = cell.value.split(":");
    hour= _.toNumber(cellVal[0]);
    min = _.toNumber(cellVal[1]);
    sec = _.toNumber(cellVal[2]);
    cellValLen = cellVal.length;
  } 
console.log(hour,min,sec);
  if( cellValLen != 3
  || _.isNaN(hour)
  || _.isNaN(min)
  || _.isNaN(sec)
  || 0 > hour|| hour >= 24 
  || 0 > min || min  >= 60 
  || 0 > sec || sec  >= 60  ){
    debugger;
    str =  `<del>${hour}:${min}:${sec}</del> `;
  }else{
    str =  `${hour}:${min}:${sec}`;
  }

  return str;
}
// export const rows = [
//   {
//     Name: "Kessie",
//     FullName: "Vijendra N. Raj",
//     Email: "mus.Donec.dignissim@Praesent.edu",
//     Company: "Arcu Et Pede Incorporated",
//     Age: "17",
//   },
//   {
//     Name: "Evelyn",
//     FullName: "Hridaynath K. Ismail",
//     Email: "fringilla.euismod@elementum.edu",
//     Company: "Aliquam Tincidunt Ltd",
//     Age: "28",
//   },
// ];

const formatUTCDate = (utcDate, format) => {
  const date = new Date(utcDate); // UTC 값을 Date 객체로 변환합니다.

  const year = date.getUTCFullYear(); // UTC 연도를 가져옵니다.
  const month = date.getUTCMonth() + 1; // UTC 월을 가져옵니다. (0부터 시작하므로 1을 더해줍니다.)
  const day = date.getUTCDate(); // UTC 일을 가져옵니다.
  const hours = date.getUTCHours(); // UTC 시간을 가져옵니다.
  const minutes = date.getUTCMinutes(); // UTC 분을 가져옵니다.
  const seconds = date.getUTCSeconds(); // UTC 초를 가져옵니다.

  // 포맷 형식에 맞게 날짜를 조합합니다.
  const formattedDate = format
    .replace('YYYY', year)
    .replace('MM', month.toString().padStart(2, '0'))
    .replace('DD', day.toString().padStart(2, '0'))
    .replace('HH', hours.toString().padStart(2, '0'))
    .replace('MI', minutes.toString().padStart(2, '0'))
    .replace('SS', seconds.toString().padStart(2, '0'));

  return formattedDate;
}