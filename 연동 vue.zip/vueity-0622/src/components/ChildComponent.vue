<template>
 <div>나는 자식</div>
</template>

<script setup lang="ts">


const testCallMe = ()=>{
  alert("EE")
}
</script>
