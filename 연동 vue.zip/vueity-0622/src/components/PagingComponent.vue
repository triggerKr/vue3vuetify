<template>
  <div>
    <nav>
      <ul class="pagination">

        <li :class="['page-item', { 'disabled': isFirstDisabled }]">
          <a :class="['page-link',{ 'aria-disabled': isFirstDisabled }]" 
            @click="makePageList(1)">&lt;&lt;</a>
        </li>
        <li :class="['page-item', { 'disabled': isPrevDisabled }]">
          <a :class="['page-link',{ 'aria-disabled': isPrevDisabled }]" 
            @click="makePageList(pageIdx-1)">&lt;</a>
        </li>

        <li :class="['page-item',{ 'active': ii === pageIdx }]" v-for="ii in numbers" :key="ii">
          <a class="page-link" @click="makePageList( ii)">{{ ii }}</a>
        </li>

        <li :class="['page-item',{ 'disabled': isNextDisabled }]">
          <a :class="['page-link',{ 'aria-disabled': isNextDisabled }]"
            @click="makePageList(pageIdx+1)">&gt;</a>
        </li>
        <li :class="['page-item',{ 'disabled': isLastDisabled }]">
          <a :class="['page-link',{ 'aria-disabled': isLastDisabled }]"
            @click="makePageList(totalPage)">&gt;&gt;</a>
        </li>

      </ul>
    </nav>
  </div>
</template>
<script setup>
  import { ref, onMounted, defineProps }  from 'vue';
  const props = defineProps(['allRows','rowsPerPage','pageRange']);
  const emit = defineEmits(['clickPage']);

  const totalPage = ref(0);
  const pageRange = ref(props.pageRange);

  const startPageIdx = ref(0);
  const endPageIdx = ref(props.pageRange)

  const numbers = ref([]);

  const isFirstDisabled = ref(false);
  const isPrevDisabled = ref(false);
  const isNextDisabled = ref(false);
  const isLastDisabled = ref(false);

  const pageIdx = ref(1);

  onMounted(() => { 
      totalPage.value = Math.ceil(props.allRows / props.rowsPerPage ) ;  
      makePageList(1);}
  );



  const makePageList = ( pg) => {
    
    if( pg <= 1)pageIdx.value = 1;
    else if( totalPage.value < pg)pageIdx.value = totalPage.value;
    else pageIdx.value = pg;
    
    startPageIdx.value	= Math.floor((pageIdx.value - 1) / pageRange.value) * pageRange.value + 1 // 현재 클릭한 pageIdx가 3이라면  F( ( 3-1 ) / 10 ) * 10 + 1 = 0 * 10 +1 = 1 startPageIdx ;
    endPageIdx.value		= startPageIdx.value + pageRange.value - 1; // 마지막 페이지 인덱스 1 + 10 -1 = 10 endPageIdx
    
    if(endPageIdx.value > totalPage.value) endPageIdx.value = totalPage.value;

    const max = endPageIdx.value - startPageIdx.value +1;

    numbers.value=[];
    for(let ii=0 ; ii< max ; ii++){
      numbers.value.push(ii + startPageIdx.value);
    }

    setDisable();

    emit('clickPage', pageIdx.value);
  };

  const setDisable = ()=>{

    if(startPageIdx.value < pageRange.value) isFirstDisabled.value = true;
    else isFirstDisabled.value = false;
    
    if(startPageIdx.value > totalPage.value-pageRange.value) isLastDisabled.value = true;
    else isLastDisabled.value = false;

    if( pageIdx.value == 1)isPrevDisabled.value = true; else isPrevDisabled.value = false;
    if( pageIdx.value == totalPage.value )isNextDisabled.value = true; else isNextDisabled.value = false; 
  }
</script>

<style>  
.pagination {
  display: flex;
  justify-content: center;
  background-color: rgb(251, 247, 247);
  padding: 10px 0;
}

 .page-item {
  list-style: none;
}

.page-item:hover {
  color: white;
  font-weight: bold;
}

.page-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 1px 5px;
  color: black;
  text-decoration: none;
  background-color: white;
  border: 1px solid white;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}  
.page-link.active:hover,
.page-link:hover {
  background-color:  grey;
} 
.page-item.active>.page-link {
    background-color:  grey;
}

.page-link:focus,

.disabled {
pointer-events: none;
opacity: 0.6;
}
</style> 