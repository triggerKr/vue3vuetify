import ko from '@/locales/ko.json'
import en from '@/locales/en.json'

export default {
  'ko': ko,
  'en': en
}