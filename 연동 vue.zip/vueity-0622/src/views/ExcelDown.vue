<template>
  <div>
    <p v-if="data">{{ data }}</p>
    <p v-else>Loading...</p>
  </div>
</template>

<script setup lang="ts">

import { ref, onMounted } from 'vue';
import axios from 'axios';
const data = ref(null);

onMounted(async () => {
  try {
    const response = await axios.get('http://localhost:8082/v1/download',{
      responseType:'blob' //이진 데이터로 응답받기
    }).then(response => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'example.xlsx'); // 다운로드할 파일 이름 설정
      document.body.appendChild(link);
      link.click();
    })
    .catch(error => {
      console.error('파일 다운로드 에러:', error);
    });
    
  } catch (error) {
    console.error(error);
  }
});
</script>
