<template>
  <div class="about pa-6">
    <h1>About Vuetify Todo</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
  </div>
  <v-checkbox :label="`체크빡스 ${abcCheckbox.toString()} `" :model-value="abcCheckbox"  @click="FFFO"></v-checkbox>
  <v-checkbox :label="`체크빡스 ${ccc.toString()}`" v-model="ccc" @click="AAAA"></v-checkbox>

</template>

<script setup lang="ts">

import { ref } from 'vue';
const axa = JSON.parse('false');
const abcCheckbox = ref(axa); 
const ccc = ref(false);
const id = ref('');
const checked = ref('');
const name = ref('');
const disabled = ref('');
const onClicked = ref('');
const value = ref('');


function FFFO(event){
  
  const chkId = event.target.__vnode.props.id;
  if( chkId == document.getElementsByClassName('mdi-checkbox-marked')[0]?.nextSibling.id ){
    console.log("체크푼다");
  }else {
    console.log('체크한다.')
  }
} 

function AAAA(event){
  debugger;
  const chkId = event.target.__vnode.props.id;
  if( chkId == document.getElementsByClassName('mdi-checkbox-marked')[0]?.nextSibling.id ){
    console.log("체크푼다");
  }else {
    console.log('체크한다.')
  }
} 
</script>
