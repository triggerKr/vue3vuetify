<template>
  <h2>Pagination TEST </h2>
  <Hr/>
  <h3>CLICKED PAGE : {{curpage}}</h3>
 <pagination  :allRows="allRows" 
              :rowsPerPage="rowsPerPage"
              :pageRange="pageRange"
              @clickPage="clickPage"
 ></pagination>
</template>
<script setup>
  import { ref, onMounted, computed }  from 'vue';
  import pagination  from '../components/PagingComponent.vue';
  
  const allRows = ref(463);
  const rowsPerPage = ref(20);
  const pageRange = ref(10);
  const curpage = ref(0);

  onMounted(() => { debugger; console.log("GGGG");});

  const clickPage = (curPage) => curpage.value =  curPage;
</script>
<style>   
</style> 