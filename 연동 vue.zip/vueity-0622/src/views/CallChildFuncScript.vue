<template>
  <ChildComponent ref="childRef" />
</template>

<script>
import ChildComponent from '@/components/ChildComponent.vue';

export default {
  components: {
    ChildComponent,
  },
  mounted() {

    //this.$refs.childRef.testCallMe();
  },
};
</script>