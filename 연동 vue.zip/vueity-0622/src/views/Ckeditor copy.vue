<template>
  <div>
    XXXXXXXXXXXXXXXXXXXXXXXX
    <ckeditor :editor="editor" v-model="editorData" :config="editorConfig"
    @ready="onEditorReady">
  </ckeditor>
  </div>
</template>

<script setup lang="ts">
//

import { ref, nextTick } from 'vue';
//import ckEditorType '@ckeditor/ckeditor5-build-classic/build/ckeditor';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import CKEditor from '@ckeditor/ckeditor5-vue'; /// editor5-vue 를 전역으로 설치해도 되고, 로컬에 설치해도 됨.
import { EditorConfig } from '@ckeditor/ckeditor5-core';
const ckeditor= CKEditor.component;
const editor =  ClassicEditor;
const editorData = '<p>Content of the editor.</p>';
const editorConfig:EditorConfig = {
        toolbar: [ 
                'heading', 
                '|', 
                'bold', 
                '|',
                'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ,'imageUpload' ],
        heading: {
            options: [
            //{ model: 'paragraph', view: 'Paragraph',title: 'Paragraph', class: 'ck-heading_paragraph' }, 이게 에러나서 view부분을 삭제
            { model: 'paragraph',  title: 'Paragraph', class: 'ck-heading_paragraph' },
            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },

            ]
        }
            
        }

    const onEditorReady = () => {
      // 컨텐츠 높이 동적 변경
      const newHeight = '500px'; // 원하는 높이 값
      const editorElement = this.editorInstance.sourceElement;
      editorElement.style.height = newHeight;
    }        
</script>

<style>
  /* CKEditor 스타일을 조정할 수 있습니다. */
  .ck-editor__editable {
    min-height: 300px;
  }
</style>
