<template>
  <!-- <h2>{{ $t('login_info') }}</h2> -->
  <H2>리얼그리드 칼렌다s</H2>
    <!-- ...other code... -->
    <div class="calendar-container">
      <input type="text" v-model="showCalendar" @focus="openCalendar" />
      <DatePicker v-if="showCalendar" 
        v-model="date"
        mode="date"
        :masks="masks"
        @click="closeCalendar">
        <template #default="{ inputValue, inputEvents }">
          <BaseInput :value="inputValue" v-on="inputEvents" />
      </template>
      </DatePicker>
      

    </div>
    <div class="red-border">
    </div>
  <RealGrid />

  <!-- <Page ref="page"
        :total-row="totalRow"
        @change="change" 
        :value="pageNumber"
        language="en"
        :page-number=true
        :page-size-menu="[10, 20, 50, 100,500]"
        :info=true
        :first=true
  /> -->
  <!-- <div style="aling='center'">
  <Page ref="page"
        language="en"
        :total-row="totalRow"
        @change="change" 
        :value="pageNumber"
        :page-number=true
        :page-size-menu="[10, 20, 50, 100,500]"
        :info=true
        :first=true
  /></div> -->
<!-- 
  <t-pagination
  :total-items="totalRow"
  :per-page="10"
  :limit="10"
  v-model="pageNumber"
/> -->
<!-- <jw-pagination :items="exampleItems" ></jw-pagination> -->

<!-- <v-pagination
    v-model="pageNumber"
    :pages="10"
    :range-size="1"
    active-color="#DCEDFF"
    @update:modelValue="updateHandler"
  /> -->

  <v-pagination
    v-model="pageNumber"
    :pages="20"
    :range-size="5"
    active-color="red" 
    @update:modelValue="change"
  />

</template>
<!-- 

<template>
  <VDatePicker v-model="date">
    <template #default="{ inputValue, inputEvents }">
      <BaseInput :value="inputValue" v-on="inputEvents" />
    </template>
  </VDatePicker>
</template> -->

<script setup lang="ts">
import { ref,onMounted } from 'vue';
//import { $t } from '../main' 
import RealGrid from '@/components/RealGrid.vue'; 
import { Calendar, DatePicker } from 'v-calendar';
import 'v-calendar/style.css';
// import JwPagination from 'jw-vue-pagination';

import VPagination from "@hennge/vue3-pagination";
import "@hennge/vue3-pagination/dist/vue3-pagination.css";
//import { Page } from 'v-page'

// import VueTailwind from 'vue-tailwind'
// import {
//   TPagination,
// } from 'vue-tailwind/dist/components'

const pageNumber = ref(3)
const totalRow = ref(1000)
const list = ref([])
const page = ref(null)
const exampleItems = [...Array(150).keys()].map(i => ({ id: (i+1), name: 'Item ' + (i+1) }));
// respond for pagination change
function change (data) {
  debugger;
  console.log(data) // { pageNumber: 1, pageSize: 10 }
  // a case for example
  // do some http request
  // fetch new data and update `totalRow` variable
  // axios({
  //   pageNumber: data.pageNumber,
  //   pageSize: data.pageSize
  // }).then(resp => {
  //   list.value = resp.list || []
  //   totalRow.value = resp.totalRow
  // })
}


const date = ref(new Date());
const showCalendar = ref(true);
const masks = ref({modelValue:'YYYY-MM-DD'})
const openCalendar = () =>{
  showCalendar.value = true;
}
const closeCalendar = () =>{
  showCalendar.value = false;
}
onMounted(async () => {
  showCalendar.value = true;
  page.value.goPage(3)
});
</script>

<style>
@import '../../node_modules/realgrid/dist/realgrid-style.css';
#app {
  position: relative; /* 리얼그리드가 가려지지 않도록 해줍니다 */
  z-index: 1; /* .calendar-overlay보다 낮은 z-index로 설정합니다 */
}
 /* .calendar-container {
  position: absolute;
  top: 250px;
  left: 150px;
}  */
/* .calendar-container {
  position: relative;
} */
.calendar-container {
  position: relative;
  width: 200px; /* 달력 컨테이너의 원하는 너비 설정 */
  height: 150px; /* 달력 컨테이너의 원하는 높이 설정 */
  box-sizing: border-box; /* 패딩과 테두리를 지정된 너비와 높이에 포함 */
  background-color: rgba(0, 0, 0, 0.5); /* 배경색 설정 */
 }
.calendar-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 9999; /* 리얼그리드 컴포넌트보다 높은 z-index로 조정하세요 */
  background-color: rgba(0, 0, 0, 0.5); /* 배경색 설정 */
  pointer-events: none; /* 이벤트 전달 방지 */
}
.calendar-popup {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 10000; /* calendar-overlay보다 높은 z-index로 조정하세요 */
  background-color: white; /* 배경색 설정 */
  border: 1px solid black; /* 테두리 설정 */
  padding: 10px; /* 패딩 설정 */
}
.vc-container{
  background-color: blueviolet;
  z-index:1000;
}
#realgrid-container {
  position: relative;
  z-index: 0;
}

.realgrid-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 9998; /* calendar-overlay보다 낮은 z-index로 설정하세요 */
  background-color: rgba(12, 7, 79, 0.5); /* 배경색 설정 */
}

.red-border {
  border: 2px solid red;
  height: 200px;
}

  .v-pagination__list {
  display:none;
}

.v-pagination__info {
  display:none;
}
</style>