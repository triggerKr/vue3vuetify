<template>
  <div>
    <ckeditor 
      :editor="editor" 
      v-model="editorData" 
      :config="editorConfig"
      @ready="onReady" 
      @onInput="onInput"
      ></ckeditor>
  </div>
</template>
<script setup lang="ts">
/**
  BASE64 이미지 첨부  

*/
import { ref, nextTick } from 'vue';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import CKEditor from '@ckeditor/ckeditor5-vue'; /// editor5-vue 를 전역으로 설치해도 되고, 로컬에 설치해도 됨.

import {UploadAdapter} from '@/plugins/ckeditorUploadAdapter';
function Base64UploaderPlugin(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
        return new UploadAdapter(loader, editor.t);
    };
}

const ckeditor= CKEditor.component;
const editor =  ClassicEditor;
const editorData = '<p>Content of the editor.</p>';
const editorConfig = {
        extraPlugins: [Base64UploaderPlugin],
        toolbar: [ 'heading', '|', 'bold', '|','italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ,'imageUpload' ],
        language: 'ko',
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                { model: 'heading3', view: 'h2', title: 'Heading 3', class: 'ck-heading_heading3' }
            ]
        }
            
}

const onReady = () =>{
  console.log("==========> onReady")
}

const onInput = (event:any) =>{
  
  console.log("==========> onReady")
}
</script>

<style>
  /* CKEditor 스타일을 조정할 수 있습니다. */
  .ck-editor__editable {
    min-height: 300px;
  }
</style>
