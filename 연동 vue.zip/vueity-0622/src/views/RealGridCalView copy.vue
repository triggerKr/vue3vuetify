<template>
  <!-- <h2>{{ $t('login_info') }}</h2> -->
  <H2>리얼그리드 칼렌다s</H2>
    <!-- ...other code... -->
    <div class="calendar-container">
      <input type="text" v-model="showCalendar" @focus="openCalendar" />
      <DatePicker v-if="showCalendar" @click="closeCalendar" />
    </div>
  <RealGrid />
</template>

<script setup lang="ts">
import { ref,onMounted } from 'vue';
//import { $t } from '../main' 
import RealGrid from '@/components/RealGrid.vue'; 
import { Calendar, DatePicker } from 'v-calendar';
import 'v-calendar/style.css';

const showCalendar = ref(false);

const openCalendar = () =>{
  showCalendar.value = true;
}
const closeCalendar = () =>{
  showCalendar.value = false;
}
onMounted(async () => {
});
</script>

<style>
@import '../../node_modules/realgrid/dist/realgrid-style.css';
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
}
 /* .calendar-container {
  position: absolute;
  top: 250px;
  left: 150px;
}  */
/* .calendar-container {
  position: relative;
} */
.calendar-container {
  position: relative;
  width: 200px; /* Set the desired width */
  height: 150px; /* Set the desired height */
  box-sizing: border-box; /* Include padding and border in the specified width and height */
}
</style>
