<template>
  <!-- <h2>{{ $t('login_info') }}</h2> -->
  <H2>리얼그리드</H2>
  <RealGrid />
</template>

<script setup lang="ts">
import { ref,onMounted } from 'vue';
//import { $t } from '../main' 
import RealGrid from '@/components/RealGrid.vue'; 

onMounted(async () => {
});
</script>

<style>
@import '../../node_modules/realgrid/dist/realgrid-style.css';
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
}
</style>
