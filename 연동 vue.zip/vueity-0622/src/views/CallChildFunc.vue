<template>
** 부모 컴포넌트에서 자식컴포넌트 호출
<ChildComponent ref="childRef"/>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import ChildComponent  from '@/components/ChildComponent.vue';

const childRef = ref();
onMounted(async () => {
  //childRef.value.testCallMe();
});

</script>
