<template>
  <div>
    <ckeditor 
      :editor="editor" 
      v-model="editorData" 
      :config="editorConfig"
      @ready="onReady" 
      ></ckeditor>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from 'vue';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import CKEditor from '@ckeditor/ckeditor5-vue'; /// editor5-vue 를 전역으로 설치해도 되고, 로컬에 설치해도 됨.

// 여기는 플러그 인들을 import 하면 중복 
//import { Essentials } from '@ckeditor/ckeditor5-essentials';
// import { Bold, Italic } from '@ckeditor/ckeditor5-basic-styles';
// import { Link } from '@ckeditor/ckeditor5-link';
// import { Paragraph } from '@ckeditor/ckeditor5-paragraph';


import {UploadAdapter} from '@/plugins/ckeditorUploadAdapter';
function Base64UploaderPlugin(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
        return new UploadAdapter(loader, editor.t);
    };
}

const ckeditor= CKEditor.component;
const editor =  ClassicEditor;
const editorData = '<p>Content of the editor.</p>';
const editorConfig = {
        extraPlugins: [Base64UploaderPlugin],
  // plugins: [
  //             //Essentials,
  //             // Bold,
  //             // Italic,
  //             // Link,
  //             // Paragraph
  //           ],
        toolbar: [ 'heading', '|', 'bold', '|','italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ,'imageUpload' ],
        language: 'ko',
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                { model: 'heading3', view: 'h2', title: 'Heading 3', class: 'ck-heading_heading3' }
            ]
        }
            
}

const onReady = () =>{
  alert("EE")
}
</script>

<style>
  /* CKEditor 스타일을 조정할 수 있습니다. */
  .ck-editor__editable {
    min-height: 300px;
  }
</style>
