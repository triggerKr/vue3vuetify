<template>
  <div class="paging">
    <nav class="app-pagination">
      <ul class="pagination justify-content-center">
        <li class="page-item"  >
          <a class="page-link">Prev</a>
        </li>

        <li class="page-item"  >
          <a class="page-link"  >1</a>
          <a class="page-link"  >2</a>
          <a class="page-link"  >3</a>
          <a class="page-link"  >4</a>
          <a class="page-link"  >5</a>
          <a class="page-link"  >6</a>
          <a class="page-link"  >7</a>
          <a class="page-link"  >8</a>
          <a class="page-link"  >9</a>
          <a class="page-link"  >10</a>
        </li>

        <li class="page-item" >
          <a class="page-link">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>
<style>  
.paging {
  background-color: brown;
}

.app-pagination {
  background-color: brown;
}

.pagination {
  display: flex;
  justify-content: center;
  background-color: rgb(251, 247, 247);
  padding: 10px 0;
}

.page-item {
  list-style: none;
}

.page-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 5px 10px;
  color: white;
  text-decoration: none;
  background-color: brown;
  border: 1px solid white;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.page-link:hover {
  background-color: darkbrown;
}

.page-link.active {
background-color: darkred;
}

.page-link:focus {
outline: none;
}

.disabled {
pointer-events: none;
opacity: 0.6;
}

li:hover{background: black;}
li:hover a { color: white; font-weight: bold } 
</style> 