<template>
  <div class="paging">
    <nav class="app-pagination">
      <ul class="pagination justify-content-center">
        <li class="page-item" :class="{ 'disabled': disabled }" :aria-disabled="disabled">
          <a class="page-link" :href="makePageList(pageId, listDomId, prevPageIdx)">Prev</a>
        </li>
        
        <li class="page-item" :class="isActiveClass(no)" v-for="no in numbers" :key="no.id">
          <a class="page-link" :href="makePageList(pageId, listDomId, no)">{{ no }}</a>
        </li>
        
        <li class="page-item" :class="{ 'disabled': disabled }">
          <a class="page-link" :aria-disabled="disabled" :href="makePageList(pageId, listDomId, nextPageIdx)">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const pageId = ref('yourPageId');
const listDomId = ref('yourListDomId');
const prevPageIdx = ref('yourPrevPageIdx');
const nextPageIdx = ref('yourNextPageIdx');

const numbers = computed(() => {
  // your logic to generate the array of numbers
  return [1, 2, 3, 4, 5];
});

const disabled = ref(false);

const makePageList = (pageId, listDomId, index) => {
  // your makePageList function logic
  // replace with your actual implementation
  console.log(pageId, listDomId, index);
};

const isActiveClass = (no) => {
  // your isActiveClass function logic
  // replace with your actual implementation
  return no === activeNo ? 'active' : '';
};
</script>
<style>
.paging {
  /* your paging styles */
}

.app-pagination {
  /* your app-pagination styles */
}

.pagination {
  /* your pagination styles */
}

.page-item {
  /* your page-item styles */
}

.disabled {
  /* your disabled styles */
}

.page-link {
  /* your page-link styles */
}

.active {
  /* your active styles */
}
</style>