<template>
  <div class="paging">
    <nav class="app-pagination">
      <ul class="pagination justify-content-center">
        <li class="page-item"  >
          <a class="page-link">Prev</a>
        </li>

        <li class="page-item"  >
          <a class="page-link"  >1</a>
          <a class="page-link"  >2</a>
          <a class="page-link"  >3</a>
          <a class="page-link"  >4</a>
          <a class="page-link"  >5</a>
          <a class="page-link"  >6</a>
          <a class="page-link"  >7</a>
          <a class="page-link"  >8</a>
          <a class="page-link"  >9</a>
          <a class="page-link"  >10</a>
        </li>

        <li class="page-item" >
          <a class="page-link">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<style>
.paging {
  background-color: brown;
}

.app-pagination {
  background-color: brown;
}

.pagination {
  display: flex;
  justify-content: center;
  background-color: rgb(251, 247, 247);
  padding: 10px 0;
}
.page-item:hover .page-link {
  color: white;
  font-weight: bold;
}

.page-link.active:hover,
.page-link:hover {
  background-color: darkred;
}

.page-link.active:hover {
  cursor: default;
}

.page-link:focus,
.page-link:hover:not(.active) {
  background-color: brown;
}

</style>