<template>
    <div class="paging">
      <nav class="app-pagination">
        <ul class="pagination justify-content-center">
          <li class="page-item" :class="{ 'disabled': disabled }">
            <a class="page-link" :aria-disabled="disabled" @click="makePageList(pageId, listDomId, 1)">Prev</a>
          </li>

          <li class="page-item" :class="{ 'active': ii === pageIdx }" v-for="ii in numbers" :key="ii">
            <a class="page-link" @click="makePageList(pageId, listDomId, ii)">{{ ii }}</a>
          </li>

          <li class="page-item" :class="{ 'disabled': disabled }">
            <a class="page-link" :aria-disabled="disabled" @click="makePageList(pageId, listDomId, nextPageIdx)">Next</a>
          </li>
        </ul>
      </nav>
    </div>
</template>
<script setup>
import { ref, onMounted, computed }  from 'vue';

const defaultListRange = 10;
const defaultPageRange = 10;
const listRange = {};
const numbers = computed(() => {
  // your logic to generate the array of numbers
  return [1, 2, 3, 4, 5];
});
const listDomId = ref();
const pageId = ref('yourPageId');
const disabled = ref(false);
const pageIdx = ref(1);
const nextPageIdx = ref(2);

const makePageList = (pageId, listDomId, pageIdx) => {
  // your makePageList function logic
  // replace with your actual implementation
  alert("클릭")
  console.log(pageId.value, listDomId.value, pageIdx.value);
};

  // Vue 3에서는 onMounted() 훅을 사용하여 컴포넌트가 마운트된 후에 동작하는 로직을 정의할 수 있습니다.
  onMounted(() => {
    makePageList(pageId.value, listDomId.value, pageId.value);
  });

</script>
<style> 
.paging {
  background-color: brown;
}

.app-pagination {
  background-color: brown;
}

.pagination {
  display: flex;
  justify-content: center;
  background-color: rgb(251, 247, 247);
  padding: 10px 0;
}

.page-item {
  list-style: none;
}

.page-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 5px 10px;
  color: white;
  text-decoration: none;
  background-color: brown;
  border: 1px solid white;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.page-link:hover {
  background-color: darkbrown;
}

.page-link.active {
  background-color: darkred;
}

.page-link:focus {
  outline: none;
}

.disabled {
  pointer-events: none;
  opacity: 0.6;
}


/* 
.page-link-button {
  cursor: pointer;
  display: inline-block;
  padding: 5px 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.page-link-button:hover {
  background-color: #f0f0f0;
}
.pagination {
  
  background-color: rgb(251, 247, 247);
  display: flex;
  justify-content: center;
}

.page-item {
  
  background-color:  rgb(251, 247, 247);
  list-style: none;
}

.page-item a {
  
  background-color: rgb(251, 247, 247);
  padding: 0 10px;
  color: white;  
  text-decoration: none;
  transition: background-color 0.3s;  
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid white;  
  border-radius: 5px; 
}

.page-item a:hover {
  background-color: darkbrown;
}

.page-item a.active { 
  background-color: darkred;
}

.page-item a:focus { 
  background-color: rgb(22, 7, 7);
  outline: none;   
.active { 
  background-color: brown;
}

.paging { 
  background-color: brown;

}

.app-pagination { 
  background-color: brown;

} */

</style> 