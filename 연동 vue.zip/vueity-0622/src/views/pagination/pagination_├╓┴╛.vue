<template>
  <div class="paging">
    <nav class="app-pagination">
      <ul class="pagination justify-content-center">

        <li :class="['page-item', { 'disabled': isPrevDisabled }]">
          <a :class="['page-link', { 'aria-disabled': isPrevDisabled }]" 
            @click="makePageList(prevPageIdx)">Prev</a>
        </li>

        <li class="page-item" :class="{ 'active': ii === pageIdx }" v-for="ii in numbers" :key="ii">
          <a class="page-link" @click="makePageList( ii)">{{ ii }}</a>
        </li>

        <li class="page-item" :class="{ 'disabled': isNextDisabled }">
          <a class="page-link" :class="{ 'aria-disabled': isNextDisabled }"
            @click="makePageList(nextPageIdx)">Next</a>
        </li>

      </ul>
    </nav>
  </div>
</template>
<script setup>
import { ref, onMounted, computed }  from 'vue';

const defaultListRange = 10;
const currentPageBand = ref(1);
const totalPage = ref(0);
const pageRange = ref(defaultListRange);// 10개 << < 1,2,3,4,5,6,7,8,9,10 > >>

const startPageIdx = ref(0);
const endPageIdx = ref(defaultListRange)

const numbers = ref([]);

const disabled = ref('');
const isPrevDisabled = ref(false);
const isNextDisabled = ref(false);

const pageIdx = ref(1);
const prevPageIdx = ref(0); 
const nextPageIdx = ref(defaultListRange);

onMounted(() => makePageList(1));

const calTotalPage = () =>{
  // 예를 들어 계시물의 갯수가 463Rows 라면, 463/20건씩 보여줄것임 = 23.x ==> 24페이지
  totalPage.value = 24;
}

const makePageList = ( pg) => {
  // https://velog.io/@eunoia/JS%EB%A1%9C-Pagination-%EA%B5%AC%ED%98%84%ED%95%98%EA%B8%B0
  
  pageIdx.value = pg;
  calTotalPage();  
  // 페이지를 보여줄 그룹계산은 없음.
  startPageIdx.value	= Math.floor((pageIdx.value - 1) / pageRange.value) * pageRange.value + 1 // 현재 클릭한 pageIdx가 3이라면  F( ( 3-1 ) / 10 ) * 10 + 1 = 0 * 10 +1 = 1 startPageIdx ;
  endPageIdx.value		= startPageIdx.value + pageRange.value - 1; // 마지막 페이지 인덱스 1 + 10 -1 = 10 endPageIdx
  // 마지막 페이지 수가  총전체 페이지 보다 커지면 총전체 페이지를 마지막 페이지로 한다.
  if(endPageIdx.value > totalPage.value) endPageIdx.value = totalPage.value;

  prevPageIdx.value		= startPageIdx.value 	- 1; // 이전 페이지
  nextPageIdx.value		= endPageIdx.value 	+ 1;  // 이후 페이지

  const max = endPageIdx.value - startPageIdx.value +1;

  numbers.value=[];
  for(let ii=0 ; ii< max ; ii++){
    numbers.value.push(ii + startPageIdx.value);
  }

  setDisable();
};

const setDisable = ()=>{

  if(startPageIdx.value < pageRange.value) {
    isPrevDisabled.value = true;
  }else{
    isPrevDisabled.value = false;
  }
  if(startPageIdx.value > totalPage.value-pageRange.value) {
    isNextDisabled.value = true;
  }else{
    isNextDisabled.value = false;
  }
}

</script>
<style>  
/* .paging {
  background-color: rgb(6, 248, 236);
} */

/* .app-pagination {
  background-color: brown;
} */

.pagination {
  display: flex;
  justify-content: center;
  background-color: rgb(251, 247, 247);
  padding: 10px 0;
}

 .page-item {
  list-style: none;
}
/*
.page-item:hover {
  color: white;
  font-weight: bold;
} */


.page-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 5px 10px;
  color: white;
  text-decoration: none;
  background-color: brown;
  border: 1px solid white;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

  /* .page-link.active:hover,
.page-link:hover {
  background-color: darkred;
}  
.page-link.active:hover {
  background-color: darkred;
} */

.page-link.active:hover {
  cursor: default;
}

.page-link:focus,
.page-link:hover:not(.active) {
  background-color: rgb(24, 8, 244);
}

.disabled {
pointer-events: none;
opacity: 0.6;
}

/* li:hover{background: black;}
li:hover a { color: white; font-weight: bold }  */
</style> 