<template>
    <div class="paging">
      <nav class="app-pagination">
        <ul class="pagination justify-content-center">
          <li class="page-item" :class="{ 'disabled': disabled }">
            <a class="page-link" :aria-disabled="disabled" @click="makePageList(pageId, listDomId, 1)">Prev</a>
          </li>

          <li class="page-item" :class="{ 'active': ii === pageIdx }" v-for="ii in numbers" :key="ii">
            <a class="page-link" @click="makePageList(pageId, listDomId, ii)">{{ ii }}</a>
          </li>

          <li class="page-item" :class="{ 'disabled': disabled }">
            <a class="page-link" :aria-disabled="disabled" @click="makePageList(pageId, listDomId, nextPageIdx)">Next</a>
          </li>
        </ul>
      </nav>
    </div>
</template>

<script setup>
import { ref, onMounted, computed }  from 'vue';

const defaultListRange = 10;
const defaultPageRange = 10;
const listRange = {};
const numbers = computed(() => {
  // your logic to generate the array of numbers
  return [1, 2, 3, 4, 5];
});
const listDomId = ref();
const pageId = ref('yourPageId');
const disabled = ref(false);
const pageIdx = ref(1);
const nextPageIdx = ref(2);

const makePageList = (pageId, listDomId, pageIdx) => {
  // your makePageList function logic
  // replace with your actual implementation
  alert("클릭")
  console.log(pageId.value, listDomId.value, pageIdx.value);
};

  // Vue 3에서는 onMounted() 훅을 사용하여 컴포넌트가 마운트된 후에 동작하는 로직을 정의할 수 있습니다.
  onMounted(() => {
    makePageList(pageId.value, listDomId.value, pageId.value);
  });

</script>
<style> 
.page-link-button {
  cursor: pointer;
  display: inline-block;
  padding: 5px 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.page-link-button:hover {
  background-color: #f0f0f0;
}
.pagination {
  /* your pagination styles */
  background-color: rgb(251, 247, 247);
  display: flex;  /* 가로로 배치되도록 설정 */
  justify-content: center;  /* 가운데 정렬 */
}

.page-item {
  /* your page-item styles */
  background-color:  rgb(251, 247, 247);
  list-style: none;  /* 리스트 스타일 제거 */
}

.page-item a {
  /* your page-link styles */
  background-color: rgb(251, 247, 247);
  padding: 0 10px;
  color: white;  /* 숫자 텍스트 색상 */
  text-decoration: none;  /* 링크에 밑줄 제거 */
  transition: background-color 0.3s;  /* 배경색 변경 시 애니메이션 효과 */
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid white;  /* 테두리 스타일 */
  border-radius: 5px;  /* 테두리의 둥글기 정도 */
}

.page-item a:hover {
  /* 마우스 오버 시 스타일 */
  background-color: darkbrown;
}

.page-item a.active {
  /* 현재 페이지 스타일 */
  background-color: darkred;
}

.page-item a:focus {
  /* 클릭 시 스타일 */
  background-color: rgb(22, 7, 7);
  outline: none;  /* 클릭 포커스 스타일 제거 */
}
.active {
  /* your active styles */
  background-color: brown;
}

.paging {
  /* your paging styles */
  background-color: brown;

}

.app-pagination {
  /* your app-pagination styles */
  background-color: brown;

}

</style> 