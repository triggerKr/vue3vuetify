<template>
  <div>
    <p v-if="data">{{ data }}</p>
    <p v-else>Loading...</p>
  </div>
</template>

<script setup lang="ts">

import { ref, onMounted } from 'vue';
import axios from 'axios';
const data = ref(null);

onMounted(async () => {
  try {
    const response = await axios.get('http://localhost:8082/v1/cardList');
    data.value = response.data;
  } catch (error) {
    console.error(error);
  }
});
</script>
