<template>
  <div>
    XXXXXXXXXXXXXXXXXXXXXXXX
    <button @click="chanageheight()">CHANGE HEIGHT</button>
    <ckeditor :editor="editor" v-model="editorData" :config="editorConfig"
    @ready="onEditorReady">
    </ckeditor>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from 'vue';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import CKEditor from '@ckeditor/ckeditor5-vue';
import { EditorConfig } from '@ckeditor/ckeditor5-core';

const ckeditor = CKEditor.component;
const editor = ClassicEditor;
const editorData = '<p>Content of the editor.</p>';
const editorConfig: EditorConfig = {
  toolbar: [
    'heading',
    '|',
    'bold',
    '|',
    'italic',
    'link',
    'bulletedList',
    'numberedList',
    'blockQuote',
    'imageUpload'
  ],
  heading: {
    options: [
      { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
      { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
      { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
    ]
  }
};

const editorInstance_ = ref({});
const editorElement_ = ref({});
const onEditorReady = (editorInstance: any) => {

  const newHeight = '300px'; // 원하는 높이 값
  const editorElement = editorInstance.ui.view.editable.element;
  editorElement.style.height = newHeight;  

  editorInstance_.value = editorInstance;
  editorElement_.value = editorElement;

};


const chanageheight = ()=>{
  if( editorElement_.value.style.height == '800px'){
    editorElement_.value.style.height = '300px'  
  }else{
    editorElement_.value.style.height = '800px'
  }

}
</script>

<style>
  /* CKEditor 스타일을 조정할 수 있습니다. */
  .ck-editor__editable {
    min-height: 300px;
  }
</style>
