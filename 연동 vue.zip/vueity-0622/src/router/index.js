import { createRouter, createWebHistory } from 'vue-router'
import Todo from '../views/Todo.vue'

const routes = [
  { path: '/',                    name: 'Todo',             component: Todo },
  { path: '/pagination',          name: 'pagination',       component: () => import('../views/pagination.vue') },
  { path: '/paginationTest',      name: 'paginationTest',   component: () => import('../views/paginationTest.vue') },
  { path: '/modalPopup',          name: 'modalPopup',       component: () => import('../views/ModalPopup.vue') },
  { path: '/about',               name: 'about',            component: () => import('../views/AboutView.vue') },
  { path: '/editor',              name: 'CK EDITOR',        component: () => import('../views/Ckeditor.vue')  },
  { path: '/editor2',             name: 'CK EDITOR2',       component: () => import('../views/Ckeditor2.vue') },
  { path: '/editor3',             name: 'CK EDITOR3',       component: () => import('../views/Ckeditor3.vue') },
  { path: '/toBackend',           name: 'BACK END SERVER',  component: () => import('../views/ToBackend.vue') },
  { path: '/toBackend2',          name: 'BACK END SERVER2', component: () => import('../views/ToBackEndByMobule.vue')},
  { path: '/callChildFunc',       name: 'BACK END SERVER2', component: () => import('../views/CallChildFunc.vue')},
  { path: '/callChildFuncScript', name: 'BACK END SERVER2', component: () => import('../views/CallChildFuncScript.vue')},
  { path: '/realgrid',            name: 'REAL GRID',        component: () => import('../views/RealGridView.vue')},
  { path: '/realgridCalendar',    name: 'REAL GRID2',       component: () => import('../views/RealGridCalView.vue')},
  { path: '/excelDown',           name: 'Excel DOWN',       component: () => import('../views/ExcelDown.vue')}
]
// 맞습니다. Vue Router에서 component 속성에 import 구문을 사용하여 컴포넌트를 동적으로 로드하는 것은 코드 스플리팅의 일종입니다.
//코드 스플리팅은 애플리케이션의 번들(Bundle)을 더 작은 청크(Chunks)로 분할하여 필요한 부분만 동적으로 로드하는 것을 의미합니다. 
//이를 통해 초기 로딩 속도를 향상시키고, 사용자 경험을 최적화할 수 있습니다.
const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
