import { createApp ,ref} from 'vue'
import { createI18n } from 'vue-i18n'
import App from './App.vue'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify'
import { loadFonts } from './plugins/webfontloader'
import i18n_ko from './i18n/ko.json'
import i18n_en from './i18n/en.json'

import Page from 'v-page'

loadFonts()

const messages = {
  ko: i18n_ko,
  en: i18n_en,
}

const i18n = ref(createI18n({
  locale: 'en', // 기본 로케일 설정
  fallbackLocale: 'en', // fallback 로케일 설정
  messages:messages, // 번역 메시지 객체
}))
// export const $t = i18n.value.global.t // $t 함수를 export 합니다.

// export default i18n

createApp(App)
  .use(i18n)
  .use(router)
  .use(store)
  .use(vuetify)
  .use(Page)
  //.use( CKEditor )
  .mount('#app')
