<template>
  <v-app id="inspire">
    <v-navigation-drawer
        floating
        permanent
        v-model="drawer"
      >
         <v-list
          density="compact"
          nav
        >
        <!-- <v-list-item prepend-icon="mdi-checkbox-marked-circle-auto-outline" title="Todo"          value="home"          to="/"                  ></v-list-item>
        <v-list-item prepend-icon="mdi-checkbox-marked-circle-auto-outline" title="PaginationTest" value="page"         to="/paginationTest"    ></v-list-item>
        <v-list-item prepend-icon="mdi-checkbox-marked-circle-auto-outline" title="modal"         value="page"         to="/modalPopup"         ></v-list-item>
          <v-list-item prepend-icon="mdi-forum"                               title="About"         value="about"         to="/about"               ></v-list-item> -->
          <v-list-item prepend-icon="mdi-access-point"                        title="Editor"        value="editor"        to="/editor"              ></v-list-item>
          <v-list-item prepend-icon="mdi-file-search-outline"                 title="Editor2"       value="editor2"       to="/editor2"             ></v-list-item>
          <!--<v-list-item prepend-icon="mdi-account-key"                         title="ToBackend"     value="backend"       to="/toBackend"           ></v-list-item>
          <v-list-item prepend-icon="mdi-account-key-outline"                 title="ToBackend2"    value="backend2"      to="/toBackend2"          ></v-list-item>
          <v-list-item prepend-icon="mdi-shovel"                              title="CallChildFunc" value="callCF"        to="/callChildFunc"       ></v-list-item>
          <v-list-item prepend-icon="mdi-music-box-outline"                   title="script"        value="script"        to="/callChildFuncScript" ></v-list-item> -->
          <v-list-item prepend-icon="mdi-check-circle-outline"                title="RealGrid"      value="RealGrid"      to="/realgrid"            ></v-list-item>
          <v-list-item prepend-icon="mdi-folder-text-outline"                 title="gridCalendar"  value="gridCalendar"  to="/realgridCalendar"    ></v-list-item>
          <v-list-item prepend-icon="mdi-christianity-outline "               title="excelDown"     value="excelDown"     to="/excelDown"           ></v-list-item>
        </v-list>
      </v-navigation-drawer>
    <!-- <v-app-bar>
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>

      <v-toolbar-title>Application</v-toolbar-title>
    </v-app-bar> -->
    <v-app-bar
        app
        color="primary"
        image="milkyWay.jpg"
       
        density="prominent"
      >
        <template v-slot:image>
          <v-img
            gradient="to top right, rgba(19,84,122,.8), rgba(128,208,199,.8)"
          ></v-img>
        </template>

        <template v-slot:prepend>
          <v-app-bar-nav-icon  @click="drawer = !drawer"></v-app-bar-nav-icon>
        </template>

        <v-app-bar-title>Todo Application</v-app-bar-title>

        <v-spacer></v-spacer>

        <v-btn icon>
          <v-icon>mdi-magnify</v-icon>
        </v-btn>

        <v-btn icon>
          <v-icon>mdi-heart</v-icon>
        </v-btn>
        <div>
          <!-- 사용 가능한 언어리스트를 가져와 select 형식으로 바인딩 해준다 -->
          <!-- <select v-model="$i18n.locale" @change="ccchange">
                <option v-for="locale in $i18n.availableLocales" :key="`locale-${locale}`" :value="locale">{{ locale }}
                </option>
          </select> -->
        </div>
        <v-btn icon>
          <v-icon>mdi-dots-vertical</v-icon>
        </v-btn>
      </v-app-bar>
    <v-main style="height:70%">
      <router-view/>
    </v-main>
  </v-app>
</template>
<script setup lang="ts">
import { ref, onMounted } from 'vue';
import CKEditor from '@ckeditor/ckeditor5-vue';
//import i18n from './main';
  const drawer = ref(false);
  onMounted(() => {
    drawer.value = true ;
  });

const ccchange = (event:any)=>{
  
  if(event.target.value == 'ko'){
    alert("한글로")
  //  i18n.locale = 'ko';
  }else{
    alert("to English")
  //  i18n.locale = 'en';
  }
}
</script>