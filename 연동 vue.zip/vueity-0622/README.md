
0612
vue3 에서 i18n 사용
npm install vue-i18n


0608
수동으로 vue.config.js 파일을 추가한다음.
프락시 서버 설치하여 API서버 접근 성공.

0612
I18n 추가

0614
리얼그리드에 ceate date 컬럼과 create time 컬럼을 추가.
수정을 위해 달력 달고, 시간 체크 로직 추가

0615
로디쉬 vue파일에서 임포트할때, 껀껀이 해야 한담.
//import { toNumber } from 'lodash';
import _toNumber from 'lodash/toNumber';
import _isNaN from 'lodash/isNaN';

UTC 값을 프로젝트에 넘겨 올때, 해당 컬럼이 Date형이라면, 컬럼을 추가하고, 
추가한 컬럼에 한개는 Date형, 한개는 Time형으로 변환한다. 

0616
달력 추가

0622
material font 추가
npm install @mdi/font

