<template>
 <div class="child">나는 자식( defineProps와 defineEmits는 선언하지 않아도 돼.setup 함수 내에서 자동으로 사용)</div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue';
//import { defineProps, defineEmits } from "vue";

const props = defineProps({
    user: {Type:String,default:''},
    testParam:{Type:Number,default:0},
});

const emit = defineEmits(['callBack']);

const user = ref(props.user);
const testParamx = ref(props.testParam);


watch(user, (newValue, oldValue) => {
  console.log(`count 변경: 이전 값 = ${oldValue}, 새 값 = ${newValue}`);
});
watch(testParamx, (newValue, oldValue) => {
  alert("###")
  console.log(`count 변경: 이전 값 = ${oldValue}, 새 값 = ${newValue}`);
  calledMeTestParam(newValue, oldValue);
});

const calledMeTestParam = (newValue :any, oldValue :any)=>{
  alert("나를 TEST했니."+newValue+ " "+ oldValue);
}

const directCall = ()=>{
  alert("CALLED ME DIRECTLY !")
  emit('callBack','자식에 같다옴.');
}


/** 이렇게 하면 자식함수를 직접 호출할 수 있게 한다.  */
const exposeTest = ref(100);
defineExpose({ exposeTest , directCall });
</script>
<style>
.child {
  display: flex;
  justify-content: center;
  background-color: rgb(251, 247, 247);
  /* background-color:light-grey; */
 /* background-color: rgb(51, 102, 153); */
  padding: 10px 0;
  /* transition: background-color 1; */
  border: 1px, solid, red;
  /* text-decoration:none; */


} 

</style>