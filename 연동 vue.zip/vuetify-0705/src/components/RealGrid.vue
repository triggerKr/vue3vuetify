<template>
  <div id="realgridDiv" style="width: 100%; height: 300px"></div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { GridView, LocalDataProvider } from 'realgrid';
import { columns, fields } from '@/plugins/realgrid';
//import { toNumber } from 'lodash';
import _toNumber from 'lodash/toNumber';
import _isNaN from 'lodash/isNaN';

import axios from 'axios';

const data = ref(null);


let gridView:any;
let dataProvider: any;

onMounted(() => {
  debugger;
  setTimeout(function(){
    dataProvider = new LocalDataProvider(false);
    gridView = new GridView('realgridDiv');
    gridView.setDataSource(dataProvider);
    dataProvider.setFields(fields);
    gridView.setColumns(columns);
    gridView.displayOptions.fitStyle = "evenFill";
    gridView.sortingOptions.enabled = true;
    setData();
    gridView.onCellDblClicked = function (grid, clickData) {
      console.log(clickData);
    }
  },1000)
}); 

const setData = async () =>{
  try {
      const response = await axios.get('http://localhost:8082/v1/cardList');
      if( response.data.state == 'S'){
        const rows = response.data.USER;

        for(let row of rows){
          row["utcDate_1"] = getUtcDate1(row["utcDate"]);
          row["utcDate_2"] = getUtcDate2(row["utcDate"])
          console.log( row );
        }


        dataProvider.setRows(rows);
      }else{
        dataProvider.setRows([]);
      }
    } catch (error) {
      console.error(error);
    }
}

const getUtcDate1 = (uctDate)=>{

  let koreaTime = new Date( _toNumber(uctDate) + (9 * 60 * 60 * 1000));
  let utcDate = formatUTCDate(koreaTime,"YYYY-MM-DD")
  return utcDate;
}

const getUtcDate2 = (uctDate)=>{

  let koreaTime = new Date( _toNumber(uctDate) + (9 * 60 * 60 * 1000));
  let utcTime = formatUTCDate(koreaTime,"HH:MI:SS")

  var str ="";
  const tempVal = utcTime;
  let hour = null;
  let min = null
  let sec = null
  if( tempVal.indexOf(":") == -1 && tempVal.length == 6){
    hour = tempVal.substring(0,2);
    min = tempVal.substring(2,4);
    sec = tempVal.substring(4,6);
    str =  `${hour}:${min}:${sec}`;
  }else{
    const cellVal = utcTime.split(":");
    const spliterCnt = cellVal.length;
    hour = _toNumber(cellVal[0]);
    min = _toNumber(cellVal[1]);
    sec = _toNumber(cellVal[2]);
    if( spliterCnt != 3
    || _isNaN(hour)
    || _isNaN(min)
    || _isNaN(sec)
    || 0 > hour || hour >= 24 
    || 0 > min || min >= 60 
    || 0 > sec || sec >= 60  ){
      str =  `<del>${utcTime}</del> `;
    }else{
      str =  `${utcTime}`;
    }
  } 
  return str;
}

const formatUTCDate = (utcDate, format) => {
  const date = new Date(utcDate); // UTC 값을 Date 객체로 변환합니다.

  const year = date.getUTCFullYear(); // UTC 연도를 가져옵니다.
  const month = date.getUTCMonth() + 1; // UTC 월을 가져옵니다. (0부터 시작하므로 1을 더해줍니다.)
  const day = date.getUTCDate(); // UTC 일을 가져옵니다.
  const hours = date.getUTCHours(); // UTC 시간을 가져옵니다.
  const minutes = date.getUTCMinutes(); // UTC 분을 가져옵니다.
  const seconds = date.getUTCSeconds(); // UTC 초를 가져옵니다.

  // 포맷 형식에 맞게 날짜를 조합합니다.
  const formattedDate = format
    .replace('YYYY', year)
    .replace('MM', month.toString().padStart(2, '0'))
    .replace('DD', day.toString().padStart(2, '0'))
    .replace('HH', hours.toString().padStart(2, '0'))
    .replace('MI', minutes.toString().padStart(2, '0'))
    .replace('SS', seconds.toString().padStart(2, '0'));

  return formattedDate;
}
</script>