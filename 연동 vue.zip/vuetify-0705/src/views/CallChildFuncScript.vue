<template>
  <ChildComponent ref="childRef" />
</template>

<script script setup lang="ts">
import ChildComponent from '@/components/ChildComponent.vue';
</script>