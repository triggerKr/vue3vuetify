<template>
  <div>
    <button @click="openModal">Open Modal</button>

    <div v-if="isModalOpen" class="modal">
      <div class="modal-content">
        <span class="close" @click="closeModal">&times;</span>
        <h2>Modal Title</h2>
        <p>This is a modal window.</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'

const isModalOpen = ref(false)

const openModal = () => {
  isModalOpen.value = true
  document.body.style.overflow = 'hidden' // 스크롤 막기
}

const closeModal = () => {
  isModalOpen.value = false
  document.body.style.overflow = '' // 스크롤 활성화
}

onMounted(() => {
  document.body.style.overflow = 'auto' // 페이지가 로드될 때 스크롤 활성화
})

onBeforeUnmount(() => {
  document.body.style.overflow = '' // 컴포넌트가 해제될 때 스크롤 활성화
})
</script>

<style>
.modal {
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background-color: #fefefe;
  padding: 20px;
  border: 1px solid #888;
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
</style>
