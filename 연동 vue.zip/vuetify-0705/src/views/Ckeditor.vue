<template>
  <div>
    XXXXXXXXXXXXXXXXXXXXXXXX
    <button @click="chanageheight()">CHANGE HEIGHT</button>
    <ckeditor :editor="editor" v-model="editorData" :config="editorConfig"
    @ready="onEditorReady"
    @blur="onEditorBlur"
    @focus="onEditorFocus"
    ref="ckeditorRef">
    </ckeditor>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from 'vue';
import CKEditor from '@ckeditor/ckeditor5-vue';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';// ck editor의 구성을 설정할 수 있는 객체.
import { EditorConfig,Editor } from '@ckeditor/ckeditor5-core';

const ckeditor = CKEditor.component;
const editor = ClassicEditor;
const editorData = '<p>Content of the editor.</p>';
const editorConfig: EditorConfig = {
  toolbar: [
    'heading',
    '|',
    'bold',
    '|',
    'italic',
    'link',
    'bulletedList',
    'numberedList',
    'blockQuote',
    'imageUpload'
  ],
  heading: {
    options: [
      { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
      { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
      { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
    ]
  }
};

const editorInstanceRef = ref<HTMLElement>();
const editorElementRef  = ref<HTMLElement>();
const onEditorReady = (editorInstance: any) => {
debugger; 
  const newHeight = '300px'; // 원하는 높이 값
  const editorElement = editorInstance.ui.view.editable.element;
  editorElementRef.value = editorElement as HTMLElement;
  editorElement.style.height = newHeight;  

  editorInstanceRef.value = editorInstance;

};

const ckeditorRef = ref();
const onEditorBlur = () =>{
debugger;
  setTimeout(function(){
    if (editorElementRef.value) {
      const editorElement = editorElementRef.value?.style;
      if( editorElement?.height == '800px'){
        editorElement.height = '300px'  ;
      }else{
        editorElement.height = '800px'  ;
      }
    }
  },100)
  // debugger;
  // const editorElement = ckeditorRef.value as HTMLElement;
  // const editorInstance :any = editorInstanceRef.value ;

  // // 에디터가 포커스를 잃었을 때 높이를 변경합니다.
  // if (editorElement.style.height === '800px') {
  //   editorElement.style.height = '300px';
  // } else {
  //   editorElement.style.height = '800px';
  // }

  // if( editorInstance ){
  //   // 에디터 인스턴스를 다시 렌더링합니다.
  //   nextTick(() => {
  //     editorInstance.ui.view.resize();
  //   });
  // }
}

const onEditorFocus = () =>{
  //chanageheight();
}

const chanageheight = ()=>{

  if (editorElementRef.value) {
    const editorElement = editorElementRef.value?.style;
    if( editorElement?.height == '800px'){
      editorElement.height = '300px'  ;
    }else{
      editorElement.height = '800px'  ;
    }
  }
}
</script>

<style>
  /* CKEditor 스타일을 조정할 수 있습니다. */
  .ck-editor__editable {
    min-height: 300px;
  }
</style>
