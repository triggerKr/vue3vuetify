<template>
  <div>
    <input type="text" v-model="inputText" @input="openPopup" />
    <div v-if="isPopupVisible" class="popup-wrapper">
      <ul class="list-container" :style="{ width: popupWidth }">
        <li v-for="item in filteredItems" @click="selectItem(item)" :key="item" :class="{ 'active': selectedItem === item }" @mouseover="setSelectedItem(item)">
          {{ item }}{{ inputText }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue';

const inputText = ref('');
const isPopupVisible = ref(false);
const itemList = ['분석항목 : ', '분석항목+Tag : ', 'Tag항목 : '];
const selectedItem = ref(null);
const popupWidth = ref('');

const openPopup = () => {
  console.log("##")
  isPopupVisible.value = true;
};

const filteredItems = computed(() => {
  return itemList;
});

const selectItem = item => {
  console.log('Selected item:', item);
  alert(item + ' 선택');
};

const setSelectedItem = item => {
  selectedItem.value = item;
};

watch(inputText, () => {
  setPopupWidth();
});

const setPopupWidth = () => {
  const inputWidth = document.querySelector('input').offsetWidth;
  popupWidth.value = `${inputWidth}px`;
};
</script>

<style>
.popup-wrapper {
  position: absolute;
  top: calc(100% + 5px); /* 팝업 위치 조정 */
  left: 0;
  background-color: #ffffff; /* 팝업 배경색 변경 */
  padding: 10px;
  border: 1px solid #cccccc; /* 팝업 테두리 스타일 변경 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 팝업 그림자 효과 추가 */
  max-height: 200px; /* 팝업의 최대 높이 설정 */
  width: max-content; /* 내용에 맞게 너비 설정 */
  overflow-y: auto; /* 필요한 경우 스크롤 표시 */
  display: none;
}

.popup-wrapper.active {
  display: block;
}

.list-container {
  list-style: none; /* 리스트 점 제거 */
  padding: 0;
  margin: 0;
}

.list-container li {
  margin-bottom: 5px;
  color: #333333; /* 아이템 텍스트 색상 변경 */
  cursor: pointer;
  padding: 5px;
  border-radius: 3px; /* 아이템 테두리 둥글게 */
}

.list-container li.active {
  background-color: #0078d7; /* 선택된 아이템 배경색 변경 */
  color: #ffffff; /* 선택된 아이템 텍스트 색상 변경 */
}

.list-container li:hover {
  background-color: #f0f0f0; /* 마우스 오버 시 배경색 변경 */
  color: #333333; /* 마
우스 오버 시 텍스트 색상 변경 */
}
</style>
