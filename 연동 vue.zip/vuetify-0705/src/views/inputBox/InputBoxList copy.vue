<template>
  <div>
    <input type="text" v-model="inputText" @input="showPopup" />
    <ul v-if="isPopupVisible" class="popup-container">
      <li v-for="item in filteredList" @click="selectItem(item)">{{ item }}</li>
    </ul>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const inputText = ref('');
const isPopupVisible = ref(false);
const itemList = ref(['Item 1', 'Item 2', 'Item 3']);
const filteredList = computed(() => {
  if (inputText.value) {
    //return itemList.value.filter((item) => item.includes(inputText.value));
    return itemList.value;
  }
  return [];
});

const showPopup = () => {
  if (inputText.value) {
    isPopupVisible.value = true;
  } else {
    isPopupVisible.value = false;
  }
};

const selectItem = (item) => {
  // 선택된 항목에 대한 처리를 수행
  console.log('Selected item:', item);
  // 필요한 경우 DB 조회 등의 로직을 추가로 작성할 수 있습니다.
  isPopupVisible.value = false; // 팝업 닫기
};

</script>

<style>
.popup-container {
  display: none;
}

.popup-container.visible {
  display: block;
}
</style>
