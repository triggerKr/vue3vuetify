<template>
  <div>
    <input type="text" v-model="inputText" />
    <button @click="togglePopup">Show Popup</button>
    <div v-if="isPopupVisible" class="popup-container">
      <ul class="list-container">
        <li v-for="item in filteredItems" @click="selectItem(item)">{{ item }}</li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const inputText = ref('');
const isPopupVisible = ref(false);
const itemList = ['Item 1', 'Item 2', 'Item 3'];

const togglePopup = () => {
  isPopupVisible.value = !isPopupVisible.value;
};

const filteredItems = computed(() => {
  if (inputText.value) {
    return itemList.filter(item => item.includes(inputText.value));
  }
  return itemList;
});

const selectItem = item => {
  console.log('Selected item:', item);
  alert(item+" 선택")
};
</script>

<style>
.popup-container {
  position: absolute;
  top: 300px; /* 팝업 위치 조정 */
  left: 550px;
  height:200px;
  width:300px;
  background-color: #7e1e1e;
  padding: 10px;
  border: 1px solid #0e0505;
}

.list-container {
  list-style: none; /* 리스트 점 제거 */
  padding: 0;
  margin: 0;
}

.list-container li {
  margin-bottom: 5px;
  color: #ffffff;
}
</style>
