<template>
  <div>
    <input type="text" v-model="inputText" />
    <button @click="togglePopup">Show Popup</button>
    <div v-if="isPopupVisible" class="popup-container">
      <ul class="list-container">
        <li v-for="item in filteredItems" @click="selectItem(item)" :key="item" :class="{ 'active': selectedItem === item }" @mouseover="setSelectedItem(item)" >
          {{ item }}{{ inputText }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const inputText = ref('');
const isPopupVisible = ref(false);
const itemList = ['분석항목 : ', '분석항목+Tag : ', 'Tag항목 : '];
const selectedItem = ref(null);

const togglePopup = () => {
  isPopupVisible.value = !isPopupVisible.value;
};

const filteredItems = computed(() => {
  return itemList;
});

const selectItem = item => {
  console.log('Selected item:', item);
  alert(item + ' 선택');
};

const setSelectedItem = item => {
  selectedItem.value = item;
};
</script>

<style>
.popup-container {
  position: absolute;
  top: 300px; /* 팝업 위치 조정 */
  left: 550px;
  height: 200px;
  width: 300px;
  background-color: #ffffff; /* 팝업 배경색 변경 */
  padding: 10px;
  border: 1px solid #cccccc; /* 팝업 테두리 스타일 변경 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 팝업 그림자 효과 추가 */
}

.list-container {
  list-style: none; /* 리스트 점 제거 */
  padding: 0;
  margin: 0;
}

.list-container li {
  margin-bottom: 5px;
  color: #333333; /* 아이템 텍스트 색상 변경 */
  cursor: pointer;
  padding: 5px;
  border-radius: 3px; /* 아이템 테두리 둥글게 */
}

.list-container li.active {
  background-color: #0078d7; /* 선택된 아이템 배경색 변경 */
  color: #ffffff; /* 선택된 아이템 텍스트 색상 변경 */
}

.list-container li:hover {
  background-color: #f0f0f0; /* 마우스 오버 시 배경색 변경 */
  color: #333333; /* 마우스 오버 시 텍스트 색상 변경 */
}
</style>
