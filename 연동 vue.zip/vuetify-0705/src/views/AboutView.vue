<template>
  <div class="about pa-6">
    <h1>About Vuetify Todo</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias consequatur maxime quidem accusamus illum doloremque autem nesciunt distinctio sit ad eos harum voluptatem odit, fugiat quia, odio voluptatum iure dignissimos?
    </p>
  </div>
  <v-checkbox :label="`checkBox ${abcCheckbox.toString()} `" :model-value="abcCheckbox" @click="first"></v-checkbox>
  <v-checkbox :label="`checkBox ${ccc.toString()}`"           v-model="ccc"             @click="second"></v-checkbox>

</template>

<script setup lang="ts">

import { ref } from 'vue';
const axa = JSON.parse('false');
const abcCheckbox = ref(axa); 
const ccc = ref<boolean>(false);
const id = ref<string>('');
const checked = ref<string>('');
const name = ref<string>('');
const disabled = ref<string>('');
const onClicked = ref<string>('');
const value = ref<string>('');


function first(event: any){

  const chkId = event.target.__vnode.props.id;
  const element = document.getElementsByClassName('mdi-checkbox-marked')[0] as Element;
  if( chkId == element?.nextElementSibling?.id ){
    console.log("체크푼다");
  }else {
    console.log('체크한다.')
  }
} 

function second(event: any){

  const chkId = event.target.__vnode.props.id;
  const element =document.getElementsByClassName('mdi-checkbox-marked')[0] as Element;
  if( chkId == element?.nextElementSibling?.id ){
    console.log("체크푼다");
  }else {
    console.log('체크한다.')
  }
} 
</script>
