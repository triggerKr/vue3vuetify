<template>
  ** 부모 컴포넌트에서 자식컴포넌트 호출
<ChildComponent ref="childRef"
:user="user" 
:testParam="testParam" 
@callBack="callBack"/>

<button @click="btnClick">TEST CALL</button>
<button @click="btnDClick">DIRECTLY CALL</button>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import ChildComponent from '@/components/ChildComponent.vue';

const user      =ref("");
const testParam = ref<number>(0);
const childRef = ref();
onMounted(async () => {
  //childRef.value = $refs.childRef; // 자식 컴포넌트 인스턴스 할당
  //vue3에서 직접호출하는 방법은 defineExpose
});

const btnClick = ()=>{
  alert("!!!");
  debugger;
  testParam.value=1000;
}

const btnDClick = () =>{
  console.log( childRef.value.exposeTest );
  childRef.value.directCall() ;
}

const callBack = (param :any) => alert( param);
</script>
