<template>
  <Suspense>
    <v-app>
      <router-view></router-view>
    </v-app>
  </Suspense>
</template>
